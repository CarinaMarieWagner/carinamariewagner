
<html lang="en">
  <head>
  <meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="main.css">
   <h1 align="center">Webseite</h1>
</head>
<body>
  <h2>Welcome to my Homepage</h2>
  <p>My name is Carina Wagner and I am an austrian student.</p>
  <h4>You can contact me here:</h4>
  <article >Carina Wagner</article>
  <article>Kleopferstraße</article>
  <article>1220 Vienna</article>
  <article>Austria</article>

  <h2> About me</h2> 
  <p align="center">My name is Carina Wagner, I am from Austria. I am 16 years old and a student of a technical college in Vienna. I am living together with my mother Petra, my father Christian, my little sister Lisa and my two dogs Brenda and Terry. In my freetime I usually hang out with my friends.</p>
  <hr>
  <p align="center">I am trying really to learn something new for my software skills nearly daily. I started doing some projects in blender. I made a lot of pictures and a handful small animations in this programm already using some characters from a video game. I also started sculpting in blender but there are still a lot left in the programm I have not used yet. I programmed a few little webseites there is also still a lot to improve and getting better with.</p>
  <hr>
    <h2>Schools</h2>
<ol>
  <li><h4>Higher technical college in Vienna</h4></li>
  <article>2019 - Present</article>
  <br>
  <a  align="center" href="https://www.htl-donaustadt.at">
         <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/HTL_Donaustadt_Logo.svg/1200px-HTL_Donaustadt_Logo.svg.png"
         width="240" height="71,9">
      </a>   
  <li><h4>Gymnasium in Vienna</h4></li>
  <article>2015 - 2019</article>
  <br>
  <a href="https://www.brg-seestadt.at/">
         <img src="https://bildungshub.wien/wp-content/uploads/2020/11/sim_see_logo.png"
         width="75" height="75">
      </a>
  <li><h4>First school in Vienna</h4></li>
  <article>2011 - 2015</article>
<br>
  <a href="http://www.offene-volksschule-an-der-lobau.at/Startseite/">
         <img src="https://github.com/CarinaMarieWagner/carinawagner.github.io/blob/main/Download.jpeg?raw=true"  width="75" height="80">
      </a>
  </ol>
  <h2>Technical skills</h2>
  <ul>
    <li align="center">Word ● ● ● ● ○</li>
    <li align="center">Excel ● ● ● ○ ○</li>
    <li align="center">PowerPoint ● ● ● ● ○</li>                
    <li align="center">basic HTML-skills ● ● ○ ○ ○</li> 
    <li align="center">standard CSS-skills ● ● ○ ○ ○</li>
    <li align="center">fundametal Blender-skills ● ● ○ ○ ○</li>
    <li align="center">little Photoshop knowledge ● ○ ○ ○ ○</li>
  </ul>
  <h2> Languages</h2>
<ul>
  <li>➤ German</li>
  <article>[native speaker]</article>
  <li>➤ English</li>
  <article>[lerned english in school for circa 6 years]</article>
</ul>
<h2>Hobbys</h2>
  <article align="center">riding bike 🚴︁</article>
  <article align="center">meeting friends👤︁</article>
  <article align="center">playing computergames 🎮︁</article>
  <article align="center">beeing a captain and player of an esport team🏅︁</article>
  <article align="center">working with blender🎥︁</article>
  <article align="center">listening to music 🎧︁</article>
  <article align="center">reading 📖︁</article>
  <article align="center">playing with my sister🏓︁</article>
  <article align="center">cooking food🍴︁</article>
  <article align="center">baking cakes and cookies 🥧︁🍪</article>
<hr>
<img src="https://media.discordapp.net/attachments/830539932828172319/869345669100474388/connileinposeplatzhalter.png" width="394"  height="221"> 
  <h6>A work in progress of my work in blender with a character from a game.</h6> 
  <hr>
</body>
<footer> 
  <h6>Carina Wagner</h6>
  <h6>Munich on the 03/08/2021</h6>
 </footer>
</html>
<!--𝔈𝔦𝔫 𝔨𝔩𝔢𝔦𝔫𝔢𝔯 𝔣𝔦𝔰𝔠𝔥 𝔦𝔰𝔱 𝔢𝔦𝔫 𝔣𝔦𝔰𝔠𝔥 <>< -->
